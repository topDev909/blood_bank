@include('layout.hospitals.master')
