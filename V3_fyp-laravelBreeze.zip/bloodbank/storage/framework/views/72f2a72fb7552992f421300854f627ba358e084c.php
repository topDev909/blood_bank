<?php echo $__env->make('layout.hospitals.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php if(!empty($totalClients)): ?>
<link href="<?=env('SITE_URL');?>/css/font.css" rel="stylesheet">

             <div class="row">
            <div class="col col-lg-6 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                             <h3><?php echo e($totalClients); ?></h3>
                             <p><?php echo e(__('Total Merchants')); ?></p>
                             <form action="<?php echo e(route('manage.clients.allclients')); ?>" method="GET" style="display: flex">
						<input class="form-control" type="hidden" value="<?php echo e($from); ?>"  name="from" />
						<input class="form-control" type="hidden" value="<?php echo e($to); ?>" name="to" />
							<button type="submit" style="background-color: Transparent;background-repeat:no-repeat;border: none; " class="small-box-footer"><a class="small-box-footer"><?php echo e(__('All Merchants')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a></button>
                                        </form>

                            </div>
                            <div class="widgets-icons-2 rounded-circle bg-gradient-scooter text-white ms-auto"><i class="fa fa-users"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                <div class="col col-lg-6 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                            <h3>
                                    <?php echo e($leads); ?>

                                </h3>
                                <p><?php echo e(__('Total leads')); ?></p>
                                <form action="<?php echo e(route('manage.clients.getleads')); ?>" method="GET" style="display: flex">
						<input class="form-control" type="hidden" value="<?php echo e($from); ?>"  name="from" />
						<input class="form-control" type="hidden" value="<?php echo e($to); ?>" name="to" />
							<button type="submit" style="background-color: Transparent;background-repeat:no-repeat;border: none; " class="small-box-footer"><a class="small-box-footer"><?php echo e(__('All Leads')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a></button>
                                        </form>
                            </div>
                            <div class="widgets-icons-2 rounded-circle bg-gradient-bloody text-white ms-auto"><i class="bx bxs-user"></i>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
        </div>
        <div class="direct-tabel">
        <div class="divider-text">
            <h5 class="direct-title">Direct Merchant Submissions</h5>
            <div class="row direct-card">
                <div class="col col-lg-3 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <h3>
                                    <?php echo e($application); ?>

                                </h3>
                                <p><?php echo e(__('Total Application')); ?></p>
                                <form action="<?php echo e(route('manage.clients.getApplication')); ?>" method="GET" style="display: flex">
						<input class="form-control" type="hidden" value="<?php echo e($from); ?>"  name="from" />
						<input class="form-control" type="hidden" value="<?php echo e($to); ?>" name="to" />
							<button type="submit" style="background-color: Transparent;background-repeat:no-repeat;border: none; " class="small-box-footer"><a class="small-box-footer"><?php echo e(__('Total Application')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a></button>
                                        </form>


                            </div>
                            <div class="widgets-icons-2 rounded-circle bg-gradient-scooter text-white ms-auto"><i class="fa fa-wpforms" aria-hidden="true"></i>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

                <div class="col col-lg-3 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <h3><?php echo e($submission); ?></h3>

                                <p><?php echo e(__('Total Submission')); ?></p>
                                <form action="<?php echo e(route('manage.clients.getsubmission')); ?>" method="GET" style="display: flex">
						<input class="form-control" type="hidden" value="<?php echo e($from); ?>"  name="from" />
						<input class="form-control" type="hidden" value="<?php echo e($to); ?>" name="to" />
							<button type="submit" style="background-color: Transparent;background-repeat:no-repeat;border: none; " class="small-box-footer"><a class="small-box-footer"><?php echo e(__('Total Submission')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a></button>
                                        </form>
                                <!-- <a href="<?php echo e(route('manage.clients.getsubmission')); ?>" class="small-box-footer"><?php echo e(__('Total Submission')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a> -->

                            </div>
                            <div class="widgets-icons-2 rounded-circle bg-gradient-bloody text-white ms-auto"><i class="fa fa-upload" aria-hidden="true"></i>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col col-lg-3 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <h3><?php echo e($incomplete); ?></h3>

                                <p><?php echo e(__('Total Incomplete')); ?></p>
                                <form action="<?php echo e(route('manage.clients.getpending')); ?>" method="GET" style="display: flex">
						<input class="form-control" type="hidden" value="<?php echo e($from); ?>"  name="from" />
						<input class="form-control" type="hidden" value="<?php echo e($to); ?>" name="to" />
							<button type="submit" style="background-color: Transparent;background-repeat:no-repeat;border: none; " class="small-box-footer"><a class="small-box-footer"><?php echo e(__('Total Incomplete')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a></button>
                                        </form>

                            </div>
                            <div class="widgets-icons-2 rounded-circle bg-gradient-bloody text-white ms-auto"><i class="fa fa-clock-o" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col col-lg-3 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <h3><?php echo e($offer); ?></h3>

                                <p><?php echo e(__('Offers')); ?></p>
                                <form action="<?php echo e(route('manage.clients.getoffer')); ?>" method="GET" style="display: flex">
						<input class="form-control" type="hidden" value="<?php echo e($from); ?>"  name="from" />
						<input class="form-control" type="hidden" value="<?php echo e($to); ?>" name="to" />
							<button type="submit" style="background-color: Transparent;background-repeat:no-repeat;border: none; " class="small-box-footer"><a class="small-box-footer"><?php echo e(__('Total Offers')); ?> <i
                                            class="fa fa-arrow-circle-right"></i></a></button>
                                        </form>

                            </div>
                            <div class="widgets-icons-2 rounded-circle bg-gradient-bloody text-white ms-auto"><i class="fa fa-percent" aria-hidden="true"></i>
 </div>
                        </div>
                    </div>
                </div>
                </div>
</div>
            <div class="row">
            <div class="col col-lg-6 col-xs-6">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="row">
                            <div class="col col-lg-6 col-xs-6">
                                <h5 class="title">Submitted</h5>
                                <div class="count">
                                    <h2>$0</h2>
                                    <h5 class="title-count">Count: <?php echo e($submission); ?></h5><br>
                                    <h6>Commission($0)</h6>
                                </div>
                            </div>
                            <div class="col col-lg-6 col-xs-6">
                            <h5 class="approve-title">Offer</h5>
                            <div class="count">
                                <h2>$<?php echo e($sum); ?></h2>
                                <h5 class="title-count">Count: <?php echo e($offersubmission); ?></h5><br>
                                <h6>Commission($<?php echo e($commission); ?>)</h6>
                            </div>
                            </div>
                        </div><br>
                        <div class="col">
							<button type="button" class="btn btn-success px-5">Review Deals >> </button>
									</div><hr>
                        <div class="approved-progress">
                            <h6>Applications: <?php echo e($application); ?></h6>
                            <div class="progress mb-3">
									<div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($application* 100/$totalClients); ?>%"></div>
							</div>
                        </div>
                        <div class="Submission-progress">
                            <h6>Submission: <?php echo e($submission); ?></h6>
                            <div class="progress mb-3" style="height:7px;">
                                <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo e($submission * 100/$totalClients); ?>%"></div>
                                </div>
                        </div>

                        <div class="review-progress">
                             <h6>Incomplete: <?php echo e($incomplete); ?></h6>
                            <div class="progress mb-4" style="height:7px;">
								<div class="progress-bar" role="progressbar" style="width: <?php echo e($incomplete* 100/$totalClients); ?>%"></div>
                            </div>
                        </div>

                        <div class="offer-progress">
                            <h6>Offers: <?php echo e($offer); ?></h6>
                           <div class="progress mb-3" style="height:7px;">
                               <div class="progress-bar" role="progressbar" style="width: <?php echo e($offer* 100/$totalClients); ?>%"></div>
                           </div>
                       </div>

                        <div class="declined-progress">
                        <h6>Declined: <?php echo e($decline); ?></h6>
                        <div class="progress mb-3" style="height:7px;">
							<div class="progress-bar bg-info" role="progressbar" style="width: <?php echo e($decline * 100/$totalClients); ?>%"></div>
						    </div>

                        </div>
                    </div>
                </div>
            </div>

                <div class="col col-lg-6 col-xs-6">
                    <div class="card radius-10">
                        <div class="card-body" style="padding-bottom: 0px;">
                            <div class="row">
                            <div class="col col-lg-6 col-xs-6">
                                <h5>Final Steps</h5>

                                <div class="singned-step">
                            <ul class="custome-main-section">
                                <li class="custome-sign-section">
                                 <span class="sign-title">No Contact</span><br>
                                 <span> Count: <?php echo e($nocontact); ?></span><br>
                                <span class="total-amount">Total:$0</span>
                                </li>
                                <li class="custome-sign-section">
                                    <span class="Contract-title">Contract</span><br>
                                    <span>Count: <?php echo e($contract); ?></span><br>
                                    <span class="total-amount">Total:$37,000</span>
                                </li>
                                <li class="custome-sign-section">
                                    <span class="approved-title">Incomplete</span><br>
                                        <span>Count: <?php echo e($incomplete); ?></span><br>
                                        <span class="total-amount">Total:$240,000</span>
                                </li>
                            </ul>
                            <br>
                        </div>

                            </div>
                            <div class="col col-lg-6 col-xs-6 title-border">
                            <h5 class="fun-title">Funded Percetnage</h5>
                           <?php if((int)($funded * 100/$totalClients) < 50): ?><div class="progress-circle p<?php echo e((int)($funded * 100/$totalClients)); ?>">
                               <?php else: ?> <div class="progress-circle over50 p<?php echo e((int)($funded * 100/$totalClients)); ?>">
                                   <?php endif; ?>
                            <span><?php echo e((int)($funded * 100/$totalClients)); ?>%</span>
                            <div class="left-half-clipper">
                            <div class="first50-bar"></div>
                            <div class="value-bar"></div>
                            </div>
                            </div>
                            </div>
                            <hr style="padding: 0px;margin: 0px;">
                        <div class="row sub-fun-title">
                            <div class="col col-lg-6 col-xs-6" id="title-border">
                                <h5 class="sub-title">Submitted</h5>
                                <h4 class="price">74</h4>
                            </div>
                            <div class="col col-lg-6 col-xs-6">
                                <h5 class="fun-title">Funded</h5>
                                <h4 class="price"><?php echo e($funded); ?></h4>
                            </div>

                        </div>
                        </div>
        <?php $__env->startPush('scripts'); ?>
            <script>
                $(document).ready(function(){
    $('.progressWrapper progress').each(function(){
      var prgsVal = $(this).data('value');
      var maxN = $(this).attr('max');
      var pop = prgsVal/maxN * 100

      $(this).prev().css('left', pop + '%').text(prgsVal);
      $(this).val(prgsVal);
    });
});
                $(document).ready(function () {
                    if(!'<?php echo e($settings->company); ?>') {
                        $('#modal-create-client').modal({backdrop: 'static', keyboard: false})
                        $('#modal-create-client').modal('show');
                    }
                    $('[data-toggle="tooltip"]').tooltip(); //Tooltip on icons top

                    $('.popoverOption').each(function () {
                        var $this = $(this);
                        $this.popover({
                            trigger: 'hover',
                            placement: 'left',
                            container: $this,
                            html: true,

                        });
                    });
                });
                $(document).ready(function () {
                    if(!getCookie("step_dashboard") && "<?php echo e($settings->company); ?>") {
                        $("#clients").addClass("in");
                        // Instance the tour
                        var tour = new Tour({
                            storage: false,
                            backdrop: true,
                            steps: [
                                {
                                    element: ".col-lg-12",
                                    title: "<?php echo e(trans("Dashboard")); ?>",
                                    content: "<?php echo e(trans("This is your dashboard, which you can use to get a fast and nice overview, of all your tasks, leads, etc.")); ?>",
                                    placement: 'top'
                                },
                                {
                                    element: "#myNavmenu",
                                    title: "<?php echo e(trans("Navigation")); ?>",
                                    content: "<?php echo e(trans("This is your primary navigation bar, which you can use to get around Daybyday CRM")); ?>"
                                }
                            ]
                        });

                        var canCreateClient = '<?php echo e(auth()->user()->can('manage-client-create')); ?>';
                        if(canCreateClient) {
                            tour.addSteps([
                                {
                                    element: "#newClient",
                                    title: "<?php echo e(trans("Create New Client")); ?>",
                                    content: "<?php echo e(trans("Let's take our first step, by creating a new client")); ?>"
                                },
                                {
                                    path: 'manage/clients/create'
                                }
                            ])
                        }

                        // Initialize the tour
                        tour.init();

                        tour.start();
                        setCookie("step_dashboard", true, 1000)
                    }
                    function setCookie(key, value, expiry) {
                        var expires = new Date();
                        expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 2000));
                        document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
                    }

                    function getCookie(key) {
                        var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
                        return keyValue ? keyValue[2] : null;
                    }
                });
            </script>
        <?php $__env->stopPush(); ?>
<?php if(!$settings->company): ?>
<div class="modal fade" id="modal-create-client" tabindex="-1" role="dialog">
    <?php echo $__env->make('manage.pages._firstStep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php /**PATH D:\projects blood bank\V2_fyp-laravelBreeze\bloodbank\bloodbank\resources\views/Hospitals/auth/dashboard.blade.php ENDPATH**/ ?>