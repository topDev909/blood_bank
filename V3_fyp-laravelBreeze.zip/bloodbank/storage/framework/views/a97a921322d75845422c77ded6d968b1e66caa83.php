<footer class="py-4 bg-dark mt-auto text-center">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Online Blood Bank System 2022</div>
            <div>
                <a href="<?php echo e(__('/auth/t&c')); ?>" class="text-light">Terms and Conditions</a>
                  &middot;
            </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\free\resources\views/layouts/footer.blade.php ENDPATH**/ ?>