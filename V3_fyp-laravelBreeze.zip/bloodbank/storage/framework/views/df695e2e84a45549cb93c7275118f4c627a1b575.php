 <div class="sidebar-wrapper" data-simplebar="true">
     <div class="sidebar-header">
     <img src="<?=env('SITE_URL');?>/admin-theme/assets/images/favicon_smallbyzloans.png" type="image/png" class="img-logo">

         <h6  style="color:black;font-size:0.9rem;">Online Blood Bank System</h6>

         <div class="toggle-icon ms-auto">      <i class='bx bx-arrow-to-left'></i>

         </div>
     </div>
     <!--navigation-->
     <ul class="metismenu" id="menu">
         <li>
             <a href="<?php echo e(route('Hospitals.manage.dashboard')); ?>">
                 <div class="parent-icon"><i class='bx bx-home-circle'></i>
                 </div>
                 <div class="menu-title">Dashboard</div>
             </a>
         </li>
         <li>
             <a href="javascript:;" class="has-arrow">
                 <div class="parent-icon"><i class='lni lni-customer'></i>
                 </div>
                 <div class="menu-title">Doner</div>
             </a>
             <ul>
                 <li> <a href="<?php echo e(route('Hospitals.manage.donar')); ?>"><i
                             class="bx bx-right-arrow-alt"></i>All Donar</a>
                 </li>
             </ul>
         </li>
         <li>
             <a href="javascript:;" class="has-arrow">
                 <div class="parent-icon"><i class="lni lni-invest-monitor"></i>
                 </div>
                 <div class="menu-title">Blood Qty</div>
             </a>
             <ul>
                 <li> <a href="<?php echo e(route('Hospitals.manage.bloodqty')); ?>"><i
                             class="bx bx-right-arrow-alt"></i>Blood Qty Add</a>
                 </li>
             </ul>
         </li>
         <li>
             
             <ul>
                 
             </ul>
         </li>
         <li>
             
             <ul>
                 


             </ul>
         </li>
         <li>
             
             <ul>
                 
             </ul>
         </li>
         <li>
             
             <ul>
                 
             </ul>
         </li>

     </ul>
 </div>
<?php /**PATH D:\projects blood bank\V2_fyp-laravelBreeze\bloodbank\bloodbank\resources\views/layout/hospitals/sidebar.blade.php ENDPATH**/ ?>