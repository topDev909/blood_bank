<?php $__env->startSection('heading'); ?>
<?php echo e(__('All Donars')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<link href="<?= env('SITE_URL'); ?>/css/font.css" rel="stylesheet">
<!doctype html>
<html lang="en">

<body>

    <div class="table-responsive">
        <table class="table mb-0" id="clients-table">
            <thead class="table-light">
                <tr>
                    <th><?php echo e(__('Ic')); ?></th>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Email')); ?></th>
                    <th><?php echo e(__('Contact Number')); ?></th>
                    <th><?php echo e(__('Blood Type')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td>
                    <?php if(!empty($data['ic'])): ?>
                            <?php echo e($data['ic']); ?>

                            <?php endif; ?>
                    </td>
                    <td>
                    <?php if(!empty($data['name'])): ?>
                            <?php echo e($data['name']); ?>

                            <?php endif; ?>
                    </td>
                    <td>
                    <?php if(!empty($data['email'])): ?>
                        <?php echo e($data['email']); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!empty($data['phoneNo'])): ?>
                        <?php echo e($data['phoneNo']); ?>

                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if(!empty($data['bloodTypes']['bloodType'])): ?>
                        <?php echo e($data['bloodTypes']['bloodType']); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>
    </div>
    
    </div>
    </div>


    </div>
    </div>
    <!--end page wrapper -->
    <!--start overlay-->

    <div class="overlay toggle-icon"></div>
    <!--end overlay-->
    <!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
    <!--End Back To Top Button-->
    <footer class="page-footer">
        <p class="mb-0">Copyright © 2021. All right reserved.</p>
    </footer>

    </div>

</body>

</html>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<style type="text/css">
    .table>tbody>tr>td {
        border-top: none !important;
    }

    .table-actions {
        opacity: 0;
    }

    #clients-table tbody tr:hover .table-actions {
        opacity: 1;
    }
</style>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.hospitals.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects blood bank\V2_fyp-laravelBreeze\bloodbank\bloodbank\resources\views/Hospitals/manage/donar.blade.php ENDPATH**/ ?>