<header>
			<div class="topbar d-flex align-items-center">
				<nav class="navbar navbar-expand">
					<div class="mobile-toggle-menu"><i class='bx bx-menu'></i>
					</div>
					<div class="search-bar flex-grow-1">
						<div class="position-relative search-bar-box">
						<form action="" method="GET" style="display: flex">
						<input type="hidden" name="url" value="<?php echo e(Route::currentRouteName()); ?>">
							<input type="text" class="form-control search-control" name="search" id="searchname" placeholder="Search Records..."> <span class="position-absolute top-50 search-show translate-middle-y"><i class="bx bx-search"></i></span>
							<span class="position-absolute top-50 search-close translate-middle-y"><i class="bx bx-search"></i></span>
							<button type="submit" class="btn-primary" style="display:none;">search</button>
						</form>
						</div>
					</div>
					<div>
					<?php
    if(isset($_GET['from'])) {
      $from = $_GET['from'];
	  $to = $_GET['to'];
    }
	else{
		$from =today()->subdays(30);
		$to = now();
	}
    ?>
						<form action="" method="GET" style="display: flex">
						
							<button type="submit" class="btn-primary">search</button>
							</form>
					</div>
					<div class="top-menu ms-auto">
						<ul class="navbar-nav align-items-center">
							<li class="nav-item mobile-search-icon">
								<a class="nav-link" href="#">	<i class='bx bx-search'></i>
								</a>
							</li>

							<li class="nav-item dropdown dropdown-large">

								<div class="dropdown-menu dropdown-menu-end">
									<a href="javascript:;">

									</a>
									<div class="header-notifications-list">
											</div>

								</div>
							</li>
							<li class="nav-item dropdown dropdown-large">

								<div class="dropdown-menu dropdown-menu-end">

									<div class="header-message-list">

									</div>

								</div>
							</li>
						</ul>
					</div>
					<div class="user-box dropdown">
							<a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<?php
						// $filename = 'storage/images/'.auth()->user()->image_path;
						?>
						
							<div class="user-info ps-3">
								
							</div>
						</a>
						<ul class="dropdown-menu dropdown-menu-end">
							
						</ul>

					</div>
				</nav>
			</div>
		</header>
<?php /**PATH D:\projects blood bank\V2_fyp-laravelBreeze\bloodbank\bloodbank\resources\views/layout/hospitals/header.blade.php ENDPATH**/ ?>